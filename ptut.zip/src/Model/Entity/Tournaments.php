<?php


namespace App\Model\Entity;

use Cake\ORM\Entity;

class Tournaments extends Entity
{

}
?>
