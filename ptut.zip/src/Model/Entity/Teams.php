<?php


namespace App\Model\Entity;

use Cake\ORM\Entity;

class Teams extends Entity
{

}
?>